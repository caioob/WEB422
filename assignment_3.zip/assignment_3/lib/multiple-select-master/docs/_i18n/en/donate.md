Multiple Select is a free plug-in which be made in my spare time.

If your project get the help from Multiple Select, you can donate to Multiple Select.

With your help, I believe that I will continue to strive to let Multiple Select be better.
