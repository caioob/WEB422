### Latest release (2018-12-21)

### 1.2.2

* [bug] Fix #264: updated the default of textTemplate to .html().
* [enh] Added wrap span to label text.
* [enh] Added `destroy` method.
* [enh] Added `openOnHover` option.
* [bug] Fix #377: rebuild docs and use gh-pages.
* [bug] Fix #362: update multiple-select.css.
